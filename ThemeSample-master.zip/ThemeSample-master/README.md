## **ThemeSample**
Transparent status-bar.<br>
Switch between Light/Dark mode.<br>
Choose from available color themes.

## **Video**
![](src/video.gif)

## **Apk**
[app-debug.apk](src/app-debug.apk?raw=true)

## **License**
Licensed under the [MIT License](LICENSE)
